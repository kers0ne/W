import fetch from 'node-fetch';
import { serialize } from 'cookie';

export default async function handler(req, res) {
  const { code } = req.query;
  if (!code) {
    const redirect = encodeURIComponent(process.env.NEXT_PUBLIC_REDIRECT_URI);
    return res.redirect(`https://discord.com/api/oauth2/authorize?client_id=${process.env.DISCORD_CLIENT_ID}&redirect_uri=${redirect}&response_type=code&scope=identify%20guilds`);
  }

  const data = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    client_secret: process.env.DISCORD_CLIENT_SECRET,
    grant_type: 'authorization_code',
    code,
    redirect_uri: process.env.NEXT_PUBLIC_REDIRECT_URI,
  });
  const r = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: data,
  });
  const json = await r.json();
  const userR = await fetch('https://discord.com/api/users/@me', {
    headers: { Authorization: `${json.token_type} ${json.access_token}` },
  });
  const user = await userR.json();

  res.setHeader('Set-Cookie', serialize('token', json.access_token, { httpOnly: true, path: '/' }));
  res.redirect('/');
}
