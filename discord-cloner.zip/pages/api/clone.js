import fetch from 'node-fetch';

export default async function handler(req, res) {
  const { sourceGuildId, targetGuildId } = req.body;

  const botToken = process.env.DISCORD_BOT_TOKEN;
  const headers = {
    Authorization: `Bot ${botToken}`,
    'Content-Type': 'application/json',
  };

  // Get roles
  const rolesRes = await fetch(`https://discord.com/api/guilds/${sourceGuildId}/roles`, { headers });
  const roles = await rolesRes.json();
  for (const r of roles.filter(r => !r.managed)) {
    await fetch(`https://discord.com/api/guilds/${targetGuildId}/roles`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ name: r.name, color: r.color, permissions: r.permissions, hoist: r.hoist }),
    });
  }

  // Get channels
  const channelsRes = await fetch(`https://discord.com/api/guilds/${sourceGuildId}/channels`, { headers });
  const channels = await channelsRes.json();
  for (const ch of channels) {
    const body = {
      name: ch.name,
      type: ch.type,
      parent_id: ch.parent_id || null,
      topic: ch.topic,
      permission_overwrites: ch.permission_overwrites,
    };
    await fetch(`https://discord.com/api/guilds/${targetGuildId}/channels`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });
  }

  res.status(200).json({ success: true });
}
