import { useEffect, useState } from 'react';
import cookies from 'js-cookie';

export default function Home() {
  const [guilds, setGuilds] = useState([]);
  const [src, setSrc] = useState('');
  const [dst, setDst] = useState('');

  useEffect(() => {
    const token = cookies.get('token');
    if (!token) {
      window.location.href = '/api/auth';
      return;
    }
    fetch('https://discord.com/api/users/@me/guilds', { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(setGuilds);
  }, []);

  const clone = () => {
    fetch('/api/clone', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sourceGuildId: src, targetGuildId: dst }),
    }).then(r => r.json()).then(res => alert(res.success ? 'Cloned!' : 'Error'));
  };

  return (
    <div style={{ maxWidth: 600, margin: '50px auto', fontFamily: 'sans-serif' }}>
      <h1>Discord Server Cloner</h1>
      <p>Select source and target servers:</p>
      <select value={src} onChange={e => setSrc(e.target.value)}>
        <option>Select Source</option>
        {guilds.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
      </select>
      <select value={dst} onChange={e => setDst(e.target.value)}>
        <option>Select Target</option>
        {guilds.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
      </select>
      <button onClick={clone} disabled={!src || !dst}>Clone Structure</button>
    </div>
  );
}
